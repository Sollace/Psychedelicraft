package io.github.mattidragon.tlaapi.api.gui;

import io.github.mattidragon.tlaapi.impl.PluginsExtend;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2561;

/**
 * Provides configuration options available for all widgets.
 * @see GuiBuilder
 */
@PluginsExtend
public interface WidgetConfig {
    /**
     * Adds a tooltip to the widget.
     * @apiNote The behaviour of this method is undefined if the bounds of the widget change after calling.
     * Sometimes the tooltip may follow the widget, sometimes it may not.
     * @see #addTooltip(class_2561...)
     */
    WidgetConfig addTooltip(List<class_2561> tooltip);

    /**
     * Adds a tooltip to the widget.
     * @apiNote The behaviour of this method is undefined if the bounds of the widget change after calling.
     * Sometimes the tooltip may follow the widget, sometimes it may not.
     * @see #addTooltip(List)
     */
    default WidgetConfig addTooltip(class_2561... tooltip) {
        return addTooltip(Arrays.asList(tooltip));
    }

    /**
     * Provides the current bounds of the widget.
     * Some actions on widgets may change their bounds, such as changing alignment on a text widget.
     */
    TlaBounds getBounds();
}
